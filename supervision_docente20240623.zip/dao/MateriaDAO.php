<?php

class MateriaDAO extends DAO {
    
}
