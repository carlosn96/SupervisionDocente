<!doctype html>
<html lang="es">

    <?php
    include_once '../../includes/head.php';
    ?>
    <body>
        <!--  Body Wrapper -->
        <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
             data-sidebar-position="fixed" data-header-position="fixed">
            <!-- Sidebar Start -->
            <?php
            include_once '../../includes/aside.php';
            ?>
            <!--  Sidebar End -->
            <!--  Main wrapper -->
            <div class="body-wrapper">
                <!--  Header Start -->
                <?php
                include_once '../../includes/header.php';
                ?>
                <!--  Header End -->
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-body position-relative">

                            <?php
                            include_once '../../includes/selectorCarrera.php';
                            ?>
                            <div class="card">
                                <div class="card-header">
                                    <div class="row">
                                        <div class="col-12 text-center text-md-end">
                                            <a href="../docentes/agregarDocente.php" class="btn btn-outline-primary mb-3 mb-md-0">Agregar nuevo docente</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <h2 class="card-title text-center mb-2">Lista de profesores por carrera</h2>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col">
                                            <h3 class="card-subtitle mb-4 text-muted text-center" id="carreraPlantel"></h3>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <div class="col">
                                            <input type="text" class="form-control" id="searchInput" placeholder="Buscar profesor, materia, perfil...">
                                        </div>
                                    </div>
                                    <div id="profesor-list" class="row">
                                        <!-- Tarjetas para profesor -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal para agregar un nuevo profesor -->
        <div class="modal fade" id="addProfesorModal" tabindex="-1" aria-labelledby="addProfesorModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addProfesorModalLabel">Agregar Nuevo Profesor</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="addProfesorForm">
                            <div class="mb-3">
                                <label for="nombreProfesor" class="form-label">Nombre del Profesor</label>
                                <input type="text" class="form-control" id="nombreProfesor" required>
                            </div>
                            <div class="mb-3">
                                <label for="descripcionProfesor" class="form-label">Descripción</label>
                                <textarea class="form-control" id="descripcionProfesor" rows="3" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="fotoProfesor" class="form-label">Foto</label>
                                <input type="url" class="form-control" id="fotoProfesor" placeholder="URL de la foto" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Agregar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php
        include_once '../../includes/script.php';
        ?>
        <script src="api/listaDocentes.js"></script> 
    </body>

</html>