<?php

include_once '../../../../../loader.php';

class DocenteAPI extends API {

    public function recuperar_docentes() {
        $this->enviar_respuesta((new AdminDocente())->obtener_docentes_materias(
                        $this->data["id_carrera"],
                        $this->data["id_plantel"]));
    }

    public function guardar_docente_materias() {
        $this->data["correo_electronico"] = $this->data["correo"] . "@" . $this->data["dominio"];
        $this->data["id_coordinador"] = Sesion::info()["usuario"]->get_id_coordinador();
        $this->enviar_resultado_operacion((new AdminDocente)->guardar_docente_materias($this->data));
    }

    function eliminar() {
        $this->enviar_resultado_operacion((new AdminDocente())->eliminar($this->data["id"]));
    }
}

Util::iniciar_api("DocenteAPI");
