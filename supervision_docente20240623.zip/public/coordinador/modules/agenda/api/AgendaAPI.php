<?php

include_once '../../../../../loader.php';

class AgendaAPI extends API {

    public function agendar_supervision() {
        return $this->enviar_resultado_operacion((new AdminSupervision())->agendar_supervision(
                                $this->data["idHorario"],
                                $this->data["fechaSupervision"]));
    }

    public function recuperar_docentes() {
        return (new AdminDocente())->obtener_docentes_materias($this->data["id_carrera"], $this->data["id_plantel"]);
    }

    public function recuperar_agenda() {
        $this->enviar_respuesta([
            "docentes" => $this->recuperar_docentes()
        ]);
    }

    public function recuperar_agenda_por_fecha() {
        $this->enviar_respuesta((new AdminSupervision)->recuperar_agenda_por_fecha(
                        $this->data["fecha"],
                        Sesion::info()["usuario"]->get_id_coordinador(),
                        $this->data["id_plantel"], $this->data["id_carrera"],
        ));
    }

    public function eliminar() {
        $this->enviar_resultado_operacion((new AdminSupervision)->eliminar_horario_agendado($this->data["id_horario"]));
    }
}

Util::iniciar_api("AgendaAPI");
