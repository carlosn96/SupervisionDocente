

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Supervisión Docente | Coordinador </title>
    <link rel="shortcut icon" type="image/png" href="../../../assets/images/logos/favicon.ico" />
    <link rel="stylesheet" href='../../../assets/css/styles.min.css' />
    <link rel="stylesheet" href='https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap5.min.css' />


</head>

