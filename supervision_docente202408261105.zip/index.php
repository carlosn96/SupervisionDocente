<?php

header("Location: public/index");
