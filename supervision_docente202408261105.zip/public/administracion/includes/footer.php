<footer class="footer">
  <a href="#">Inicio</a>
  <a href="#">Nosotros</a>
  <a href="#">Servicios</a>
  <a href="#">Contacto</a>

  <p class="copyright">
    &copy; 2024 Todos los derechos reservados.
  </p>

  <p class="diseñador">
    Diseño por: <span>Eddy</span>
  </p>
</footer>