<?php

class TipoUsuario {

    public const ADMINISTRADOR = "Administrador";
    public const COORDINADOR = "Coordinador";
}
