<?php

header("Location: inicio");
